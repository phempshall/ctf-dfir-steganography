Sequence

The director of this company believes 2 of his employees are sending secret messages using some sort of mathematical code, but the messages seem to be on-topic.
