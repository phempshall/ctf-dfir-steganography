Turtles all the way down

Just an archive of *happy* turtle pictures.

You are looking for a traditional flag{}.