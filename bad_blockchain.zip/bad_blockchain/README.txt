Bad Blockchain

This new botnet is using blockchain to store backup command-and-control server IP addresses. We've extracted the Bitcoin address but it's not using the traditional OP_RETURN to hide the data. Can you find the IP address?

Note: You are looking for an IP address NOT the traditional flag{}.