Hit a brick wall

The spare key is *usually* under the doormat, a plant pot, or a rock...

You are looking for a traditional flag{}.