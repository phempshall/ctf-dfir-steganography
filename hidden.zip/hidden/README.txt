Hidden

Found in the system32 directory, this .dll file doesn't do what it says.

You are looking for a traditional flag{}.