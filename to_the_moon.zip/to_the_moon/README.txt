To the moon!

This person has been storing messages on the blockchain with Bitcoin, but we can't even find their wallet address. All we found was a grumpy cat picture. Find the wallet address to find the flag{}.

You are looking for a traditional flag{}.